df <- read.csv("inflation.csv")

colnames(df)[14] <- "Average"

gt_tbl <- df %>%
  gt(rowname_col = "Year") %>%
  tab_stubhead(label = "Year") %>%
  tab_header(
    title = md("**U.S. Monthly Inflation**"),
    subtitle = md("*2000 to 2023*")
  ) %>%
  cols_align(
    align = "center",
    columns = c(Year:Average)
  ) %>%
  cols_width(
    Year ~ px(170)
  ) %>%
  tab_source_note(
    source_note = md("Data Source: U.S. Bureau of Labor Statistics.<br> 
                     All items in U.S. city average, all urban consumers, not seasonally adjusted.")
  ) %>%
  tab_options(
    column_labels.background.color = '#f2f2f2'
  ) %>%
  data_color(
    columns = c(Jan:Average),
    colors = scales::col_numeric(
      palette = "Reds",
      domain = NULL,
      reverse = FALSE)
    )

gt_tbl

gtsave(gt_tbl, "historical_inflation.pdf")
